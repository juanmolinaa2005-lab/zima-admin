import { LoginForm } from "@/components/auth/LoginForm";

export default function LoginPage() {
  return (
    <main id="main" tabIndex={-1} className="flex min-h-dvh items-center justify-center bg-background p-5 outline-none">
      <div className="w-full max-w-[400px] animate-scale-in">
        <LoginForm />
      </div>
    </main>
  );
}
