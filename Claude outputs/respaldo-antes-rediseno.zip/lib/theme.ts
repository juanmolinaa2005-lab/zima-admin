const THEME_KEY = "zima:accent-theme";

export const BLACK_THEME = {
  accent: "#111827",
  soft: "#f3f4f6",
  hover: "#030712",
  border: "#d1d5db",
  rgb: "17, 24, 39",
} as const;

export function applyTheme() {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.style.setProperty("--accent", BLACK_THEME.accent);
  root.style.setProperty("--accent-soft", BLACK_THEME.soft);
  root.style.setProperty("--accent-hover", BLACK_THEME.hover);
  root.style.setProperty("--accent-border", BLACK_THEME.border);
  root.style.setProperty("--accent-rgb", BLACK_THEME.rgb);
  try {
    localStorage.removeItem(THEME_KEY);
  } catch {
    /* ignore */
  }
}
