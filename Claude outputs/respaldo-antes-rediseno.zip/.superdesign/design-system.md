# Zima Admin — Design system

## Product
Zima Admin (vantko) is a project workspace: pick a project, then use a 76px icon rail to open Home, Accesos, Emails, Stats, Tracker, Studio, Redes, Gallery, Settings. Spanish product chrome. Mark is a filled ink circle with a white **Z** (no logo file).

## JTBD
Open the right tool fast. Cards and rails stay quiet so media and data can be loud.

## Current visual language (ground truth)
- Canvas `#f7f7f8`, surfaces `#ffffff`, ink `#111827` / `#16181d`
- Muted `#6b7280` / `#6b7285`, faint `#9ca3af`
- Geist + Geist Mono
- Pills for buttons, chips, inputs
- Cards `rounded-[22px]`, no colored page washes
- Primary CTA: ink fill, white text
- Header 56–64px white with 1px `#ebebef` / `#e6e8ef` hairline
- Rail 76px white, 10px labels under 20px icons
- Motion: 180–200ms fade / scale-in on login and modals only

## Real information architecture (do not invent)
1. `/login` — Entrar, email, password, Docs link
2. `/` — Projects list, New project, Supabase connected, Sign out
3. Dashboard rail: Home, Clients, Emails, Analytics, Tracker, Studio, Redes, Accesos, Galería, Ajustes
4. Home: project chips, quick tool tiles, KPI cards (Clients, Emails, Analytics OpenAI, Accesos), optional spend chart
5. Accesos: Nuevo acceso first, equal tiles, favicon or custom icon
6. Estudio: Producto, Viral Content, Blitz, Creator Imagen, Influencers, App Demo, Dynamics, Library
7. Settings: API and Password only
8. Docs: Inicio and App Demo

## Constraints
- Keep the Z circle mark (do not invent a logo)
- Do not invent payments, customers, billing, balances, or any tool not listed above
- Do not cover Dynamics/Parts phone previews with decorative color
