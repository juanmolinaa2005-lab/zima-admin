"use client";

import { useEffect, useState, type ComponentType, type SVGProps } from "react";
import { useRouter } from "next/navigation";
import { signOut } from "@/app/auth/actions";
import type { Project } from "@/lib/types";
import { ConnectSupabaseModal } from "@/components/projects/ConnectSupabaseModal";
import {
  ContractIcon,
  DocumentIcon,
  GridIcon,
  LogoutIcon,
  TaskIcon,
  UsersIcon,
} from "@/components/dashboard/icons";
import { ContractsPanel } from "./ContractsPanel";
import { DocumentsPanel } from "./DocumentsPanel";
import { ProjectsPanel } from "./ProjectsPanel";
import { TasksPanel } from "./TasksPanel";
import { TeamPanel } from "./TeamPanel";
import { useBusinessWorkspace } from "./use-workspace";

export type BusinessSection =
  | "proyectos"
  | "task"
  | "documents"
  | "contratos"
  | "team";

const SECTIONS: {
  id: BusinessSection;
  label: string;
  icon: ComponentType<SVGProps<SVGSVGElement>>;
}[] = [
  { id: "proyectos", label: "Proyectos", icon: GridIcon },
  { id: "task", label: "Task", icon: TaskIcon },
  { id: "documents", label: "Documents", icon: DocumentIcon },
  { id: "contratos", label: "Contratos", icon: ContractIcon },
  { id: "team", label: "Team", icon: UsersIcon },
];

function isSection(value: string | null): value is BusinessSection {
  return SECTIONS.some((section) => section.id === value);
}

type BusinessDashboardProps = {
  projects: Project[];
  userEmail: string | null;
  supabaseConnected: boolean;
};

export function BusinessDashboard({
  projects,
  userEmail,
  supabaseConnected: initialConnected,
}: BusinessDashboardProps) {
  const router = useRouter();
  const userKey = userEmail ?? "default";
  const [workspace, updateWorkspace] = useBusinessWorkspace(userKey);
  const [section, setSection] = useState<BusinessSection>("proyectos");
  const [connected, setConnected] = useState(initialConnected);
  const [connectOpen, setConnectOpen] = useState(false);

  useEffect(() => {
    setConnected(initialConnected);
  }, [initialConnected]);

  useEffect(() => {
    const current = new URLSearchParams(window.location.search).get("section");
    if (isSection(current)) setSection(current);
  }, []);

  function go(next: BusinessSection) {
    setSection(next);
    const url = new URL(window.location.href);
    if (next === "proyectos") url.searchParams.delete("section");
    else url.searchParams.set("section", next);
    window.history.replaceState(null, "", `${url.pathname}${url.search}`);
  }

  return (
    <div className="flex min-h-dvh bg-[#f7f7f8]">
      <aside className="hidden w-[232px] shrink-0 flex-col border-r border-[#e6e8ef] bg-white md:flex">
        <div className="flex items-center gap-3 px-5 py-5">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[var(--accent)] text-[13px] font-bold text-white">
            Z
          </div>
          <div className="min-w-0">
            <p className="text-[14px] font-semibold text-[#16181d]">
              My Business
            </p>
            <p className="truncate text-[11px] text-[#6b7285]">Admin</p>
          </div>
        </div>
        <nav className="flex flex-1 flex-col gap-1 px-3">
          {SECTIONS.map((item) => {
            const active = section === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => go(item.id)}
                className={`flex w-full items-center gap-2.5 rounded-[12px] px-3 py-2.5 text-left text-[13px] font-medium transition ${
                  active
                    ? "bg-[var(--accent-soft)] text-[#111827]"
                    : "text-[#6b7280] hover:bg-[#f3f4f6] hover:text-[#111827]"
                }`}
              >
                <Icon className="h-4 w-4 opacity-70" />
                {item.label}
              </button>
            );
          })}
        </nav>
        <div className="border-t border-[#e6e8ef] p-3">
          <p className="truncate px-2 text-[11px] text-[#9aa1b2]">
            {userEmail ?? "Workspace"}
          </p>
          <form action={signOut} className="mt-1">
            <button
              type="submit"
              className="flex w-full items-center gap-2 rounded-[12px] px-3 py-2 text-left text-[13px] font-medium text-[#6b7280] hover:bg-[#fef2f2] hover:text-[#dc2626]"
            >
              <LogoutIcon className="h-4 w-4 opacity-70" />
              Sign out
            </button>
          </form>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="border-b border-[#e6e8ef] bg-white">
          <div className="flex h-14 items-center justify-between gap-3 px-4 sm:px-5">
            <div className="flex min-w-0 items-center gap-2.5 md:hidden">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-[var(--accent)] text-[12px] font-bold text-white">
                Z
              </div>
              <p className="truncate text-[14px] font-semibold text-[#16181d]">
                My Business
              </p>
            </div>
            <p className="hidden truncate text-[14px] font-semibold text-[#16181d] md:block">
              {SECTIONS.find((item) => item.id === section)?.label}
            </p>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setConnectOpen(true)}
                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-semibold transition ${
                  connected
                    ? "bg-[#ecfdf3] text-[#027a48] hover:bg-[#d1fadf]"
                    : "bg-[var(--accent-soft)] text-[var(--accent)] hover:bg-[#e5e7eb]"
                }`}
              >
                <span
                  className={`h-1.5 w-1.5 rounded-full ${
                    connected ? "bg-[#12b76a]" : "bg-[var(--accent)]"
                  }`}
                />
                {connected ? "Supabase connected" : "Connect Supabase"}
              </button>
              <form action={signOut} className="md:hidden">
                <button
                  type="submit"
                  className="inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-medium text-[#6b7285] transition hover:bg-[#fef3f2] hover:text-[#b42318]"
                >
                  <LogoutIcon className="h-3.5 w-3.5" />
                  Sign out
                </button>
              </form>
            </div>
          </div>
          <nav className="flex gap-1 overflow-x-auto px-3 pb-3 md:hidden">
            {SECTIONS.map((item) => {
              const active = section === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => go(item.id)}
                  className={`shrink-0 rounded-full px-3 py-1.5 text-[12px] font-semibold ${
                    active
                      ? "bg-[#111827] text-white"
                      : "bg-[#f3f4f6] text-[#6b7280]"
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        </header>

        <main id="main" tabIndex={-1} className="mx-auto w-full max-w-5xl flex-1 p-5 outline-none">
          {section === "proyectos" ? (
            <ProjectsPanel
              projects={projects}
              userEmail={userEmail}
              connected={connected}
              workspace={workspace}
              onNeedConnect={() => setConnectOpen(true)}
              onOpenSection={go}
            />
          ) : null}
          {section === "task" ? (
            <TasksPanel tasks={workspace.tasks} onChange={updateWorkspace} />
          ) : null}
          {section === "documents" ? (
            <DocumentsPanel
              documents={workspace.documents}
              onChange={updateWorkspace}
            />
          ) : null}
          {section === "contratos" ? (
            <ContractsPanel
              contracts={workspace.contracts}
              onChange={updateWorkspace}
            />
          ) : null}
          {section === "team" ? (
            <TeamPanel team={workspace.team} onChange={updateWorkspace} />
          ) : null}
        </main>
      </div>

      <ConnectSupabaseModal
        open={connectOpen}
        connected={connected}
        onClose={() => setConnectOpen(false)}
        onChanged={(value) => {
          setConnected(value);
          router.refresh();
        }}
      />
    </div>
  );
}
