"use client";

import { useEffect, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  deleteProject,
  fetchRemoteSupabaseProjects,
} from "@/app/actions/projects";
import type { Project } from "@/lib/types";
import {
  loadRemoteNamesCache,
  saveRemoteNamesCache,
  saveRemotesCache,
} from "@/lib/client-cache";
import { CreateProjectModal } from "@/components/projects/CreateProjectModal";
import { PlusIcon, TrashIcon } from "@/components/dashboard/icons";
import { EmptyState, SectionHead } from "./section-ui";
import type { BusinessWorkspace } from "@/lib/business/workspace-store";

type ProjectsPanelProps = {
  projects: Project[];
  userEmail: string | null;
  connected: boolean;
  workspace: BusinessWorkspace;
  onNeedConnect: () => void;
  onOpenSection: (section: "proyectos" | "task" | "documents" | "contratos" | "team") => void;
};

export function ProjectsPanel({
  projects,
  userEmail,
  connected,
  workspace,
  onNeedConnect,
  onOpenSection,
}: ProjectsPanelProps) {
  const router = useRouter();
  const userKey = userEmail ?? "default";
  const [modalOpen, setModalOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const [remoteNames, setRemoteNames] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!connected) {
      setRemoteNames({});
      return;
    }

    const cached = loadRemoteNamesCache(userKey);
    if (cached) setRemoteNames(cached.data);

    fetchRemoteSupabaseProjects()
      .then((remotes) => {
        saveRemotesCache(remotes, userKey);
        const names = Object.fromEntries(remotes.map((r) => [r.id, r.name]));
        saveRemoteNamesCache(names, userKey);
        setRemoteNames(names);
      })
      .catch(() => {
        // keep cached names if any
      });
  }, [connected, userKey]);

  function handleDelete(id: string, name: string) {
    if (!window.confirm(`Delete project “${name}”?`)) return;
    startTransition(async () => {
      await deleteProject(id);
      router.refresh();
    });
  }

  function handleCreateClick() {
    if (!connected) {
      onNeedConnect();
      return;
    }
    setModalOpen(true);
  }

  const openTasks = workspace.tasks.filter((t) => t.status !== "done").length;
  const activeContracts = workspace.contracts.filter(
    (c) => c.status === "active"
  ).length;

  return (
    <>
      {!connected ? (
        <div className="mb-5 rounded-xl bg-[var(--accent-soft)] p-5">
          <p className="text-[15px] font-semibold text-[#16181d]">
            Conecta Supabase
          </p>
          <p className="mt-1 text-[13px] text-[#6b7285]">
            Cada cuenta ve solo sus proyectos.
          </p>
          <button
            type="button"
            onClick={onNeedConnect}
            className="ui-btn-primary mt-4"
          >
            Connect now
          </button>
        </div>
      ) : null}

      <SectionHead
        kicker="My Business"
        title="Proyectos"
        description="Elige un proyecto o crea uno nuevo."
        action={
          <button type="button" onClick={handleCreateClick} className="ui-btn-primary">
            <PlusIcon className="h-4 w-4" />
            New project
          </button>
        }
      />

      <ul className="mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard
          label="Proyectos"
          value={String(projects.length)}
        />
        <StatCard
          label="Task abiertas"
          value={String(openTasks)}
          onClick={() => onOpenSection("task")}
        />
        <StatCard
          label="Contratos activos"
          value={String(activeContracts)}
          onClick={() => onOpenSection("contratos")}
        />
        <StatCard
          label="Team"
          value={String(workspace.team.length)}
          onClick={() => onOpenSection("team")}
        />
      </ul>

      {projects.length === 0 ? (
        <EmptyState
          title="Sin proyectos"
          body="Crea el primero."
          actionLabel="Create project"
          onAction={handleCreateClick}
        />
      ) : (
        <ul className="mt-5 grid gap-3 sm:grid-cols-2">
          {projects.map((project) => {
            const linked = project.supabase_project_ref
              ? remoteNames[project.supabase_project_ref] ??
                project.supabase_project_ref
              : null;
            return (
              <li key={project.id} className="group relative">
                <Link
                  href={`/projects/${project.id}`}
                  className="block rounded-xl bg-white p-5 transition hover:bg-[#fff7ed]"
                >
                  <p className="text-[15px] font-semibold text-[#16181d]">
                    {project.name}
                  </p>
                  {project.description ? (
                    <p className="mt-1 line-clamp-2 text-[13px] text-[#6b7285]">
                      {project.description}
                    </p>
                  ) : (
                    <p className="mt-1 text-[13px] text-[#9aa1b2]">
                      No description
                    </p>
                  )}
                  <p className="mt-4 text-[12px] font-medium text-[#9aa1b2]">
                    {linked
                      ? `Clients ← ${linked}`
                      : "No Supabase project linked"}
                  </p>
                </Link>
                <button
                  type="button"
                  disabled={pending}
                  onClick={() => handleDelete(project.id, project.name)}
                  className="absolute right-3 top-3 rounded-xl p-1.5 text-[#9aa1b2] opacity-0 transition hover:bg-[#fef3f2] hover:text-[#b42318] group-hover:opacity-100"
                  aria-label={`Delete ${project.name}`}
                >
                  <TrashIcon className="h-3.5 w-3.5" />
                </button>
              </li>
            );
          })}
        </ul>
      )}

      <CreateProjectModal
        open={modalOpen}
        userKey={userKey}
        connected={connected}
        onClose={() => setModalOpen(false)}
        onNeedConnect={() => {
          setModalOpen(false);
          onNeedConnect();
        }}
      />
    </>
  );
}

function StatCard({
  label,
  value,
  onClick,
}: {
  label: string;
  value: string;
  onClick?: () => void;
}) {
  const className =
    "rounded-xl bg-white p-4 text-left transition" +
    (onClick ? " hover:bg-[#f9fafb]" : "");

  const body = (
    <>
      <p className="text-[11px] font-semibold uppercase tracking-[0.08em] text-[#9aa1b2]">
        {label}
      </p>
      <p className="mt-2 text-[22px] font-semibold tracking-tight text-[#16181d]">
        {value}
      </p>
    </>
  );

  if (onClick) {
    return (
      <li>
        <button type="button" onClick={onClick} className={`w-full ${className}`}>
          {body}
        </button>
      </li>
    );
  }

  return <li className={className}>{body}</li>;
}
