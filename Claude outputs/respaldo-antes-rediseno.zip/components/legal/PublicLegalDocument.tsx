import {
  fillLegalText,
  LEGAL_DOCS,
  legalPublicSlug,
  type LegalDocId,
  type LegalPublication,
} from "@/lib/creator/app-legal";

export function PublicLegalDocument({
  published,
  docId,
}: {
  published: LegalPublication;
  docId: LegalDocId;
}) {
  const slug = legalPublicSlug(published.profile);
  const document = published.docs[docId];
  const title = fillLegalText(document.title, published.profile, published.publishedAt);
  const body = fillLegalText(document.body, published.profile, published.publishedAt);
  const updated = new Date(published.publishedAt).toLocaleDateString("es", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const blocks = body
    .split(/\n{2,}/)
    .map((block) => block.trim())
    .filter(Boolean);

  return (
    <main id="main" tabIndex={-1} className="mx-auto min-h-dvh max-w-2xl px-5 py-12 text-[#111827] outline-none">
      <p className="text-[12px] font-semibold uppercase tracking-[0.12em] text-[#9ca3af]">
        {published.profile.appName || "Documento legal"}
      </p>
      <h1 className="mt-2 text-[32px] font-semibold tracking-tight">{title}</h1>
      <p className="mt-2 text-[13px] text-[#6b7280]">
        Versión {published.version} · vigente desde el {updated}
      </p>
      <div className="mt-8 space-y-4 text-[15px] leading-relaxed text-[#374151]">
        {blocks.map((block, index) => {
          if (block.startsWith("# ")) {
            return (
              <h2 key={index} className="pt-3 text-[17px] font-semibold text-[#111827]">
                {block.slice(2)}
              </h2>
            );
          }
          return <p key={index}>{block}</p>;
        })}
      </div>
      <nav className="mt-12 flex flex-wrap gap-x-4 gap-y-2 border-t border-[#ebebef] pt-5 text-[13px]">
        {LEGAL_DOCS.map((item) => (
          <a
            key={item.id}
            href={slug ? `/${slug}/${item.path}` : `/legal/${item.path}`}
            className={
              item.id === docId
                ? "font-semibold text-[#111827]"
                : "text-[#6b7280] hover:text-[#111827]"
            }
          >
            {published.docs[item.id].label || item.label}
          </a>
        ))}
      </nav>
    </main>
  );
}
