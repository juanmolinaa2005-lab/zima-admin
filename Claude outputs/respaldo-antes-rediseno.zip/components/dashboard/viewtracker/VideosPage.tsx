"use client";

import { useEffect, useMemo, useState, type FormEvent } from "react";
import {
  engagementRate,
  formatCompact,
  formatDuration,
  formatPostedAt,
  growthMultiplier,
  timeAgo,
} from "@/lib/viewtracker/format";
import {
  AddLinksForm,
  EmptyTable,
  GrowthPill,
  PageHead,
  StatusOk,
  Toolbar,
} from "./vt-ui";

export type TrackedVideo = {
  id: string;
  url: string;
  platform: string | null;
  videoId: string | null;
  title: string | null;
  author: string | null;
  thumbnailUrl: string | null;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  saves: number;
  durationSeconds: number | null;
  postedAt: string | null;
  lastRefreshedAt: string | null;
  viewsPrev: number;
  accountId: string | null;
  favorite: boolean;
  createdAt: string;
  updatedAt: string;
};

export { formatCompact };

function platformLabel(id: string | null) {
  if (id === "tiktok") return "TikTok";
  if (id === "instagram") return "Instagram";
  if (id === "youtube") return "YouTube";
  if (id === "snapchat") return "Snapchat";
  if (id === "x") return "X";
  return id || "Web";
}

export function VideosPage({ projectId }: { projectId: string }) {
  const [items, setItems] = useState<TrackedVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");
  const [adding, setAdding] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [search, setSearch] = useState("");
  const [platform, setPlatform] = useState<string | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [menuId, setMenuId] = useState<string | null>(null);

  async function load() {
    const res = await fetch(`/api/projects/${projectId}/viewtracker/videos`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "No se pudieron cargar los videos");
    setItems((data.items ?? []) as TrackedVideo[]);
  }

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void load()
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "Error");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [projectId]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((v) => {
      if (platform && v.platform !== platform) return false;
      if (!q) return true;
      return (
        (v.title || "").toLowerCase().includes(q) ||
        (v.author || "").toLowerCase().includes(q) ||
        v.url.toLowerCase().includes(q)
      );
    });
  }, [items, search, platform]);

  async function handleAdd(e: FormEvent) {
    e.preventDefault();
    setError("");
    const raw = url.trim();
    if (!raw) {
      setError("Pega un link de TikTok, Instagram, YouTube o X.");
      return;
    }
    setAdding(true);
    try {
      const res = await fetch(`/api/projects/${projectId}/viewtracker/videos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: raw }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "No se pudo añadir");
      const created = (data.items ?? []) as TrackedVideo[];
      setItems((prev) => [
        ...created,
        ...prev.filter((v) => !created.some((c) => c.id === v.id)),
      ]);
      setUrl("");
      setFormOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo añadir");
    } finally {
      setAdding(false);
    }
  }

  async function refreshAll() {
    setRefreshing(true);
    setError("");
    try {
      const res = await fetch(`/api/projects/${projectId}/viewtracker/videos`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refreshAll: true }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "No se pudo refrescar");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "No se pudo refrescar");
    } finally {
      setRefreshing(false);
    }
  }

  async function remove(video: TrackedVideo) {
    setItems((prev) => prev.filter((v) => v.id !== video.id));
    setMenuId(null);
    const res = await fetch(
      `/api/projects/${projectId}/viewtracker/videos?id=${encodeURIComponent(video.id)}`,
      { method: "DELETE" }
    );
    if (!res.ok) setItems((prev) => [video, ...prev]);
  }

  return (
    <div className="space-y-4">
      <PageHead
        title="Videos"
        subtitle="View and analyze performance metrics across your tracked videos."
        action={
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => void refreshAll()}
              disabled={refreshing}
              className="rounded-xl border border-[#e5e7eb] bg-white px-3.5 py-2 text-[13px] font-medium text-[#374151] disabled:opacity-50"
            >
              {refreshing ? "Refreshing…" : "Refresh"}
            </button>
            <button
              type="button"
              onClick={() => setFormOpen((v) => !v)}
              className="rounded-lg bg-[var(--accent)] px-3.5 py-2 text-[13px] font-semibold text-white"
            >
              Tracking Options
            </button>
          </div>
        }
      />

      {formOpen ? (
        <AddLinksForm
          label="Video links"
          placeholder={"https://www.tiktok.com/@user/video/…\nhttps://www.youtube.com/watch?v=…"}
          value={url}
          onChange={setUrl}
          onSubmit={handleAdd}
          onCancel={() => setFormOpen(false)}
          submitting={adding}
          submitLabel="Track videos"
        />
      ) : null}

      {error ? (
        <p className="rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-[13px] text-red-700">
          {error}
        </p>
      ) : null}

      <Toolbar
        search={search}
        onSearch={setSearch}
        searchPlaceholder="Search videos"
        platform={platform}
        onPlatform={setPlatform}
        extra={
          <span className="rounded-xl border border-[#e5e7eb] bg-white px-3 py-2.5 text-[13px] text-[#6b7280]">
            All time UTC
          </span>
        }
      />

      {loading ? (
        <EmptyTable message="Cargando videos…" />
      ) : filtered.length === 0 ? (
        <EmptyTable
          message={
            items.length === 0
              ? "Pega un link en Tracking Options para empezar."
              : "No videos match your filters."
          }
        />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-[#e5e7eb] bg-white">
          <table className="min-w-[1100px] w-full text-left">
            <thead className="border-b border-[#f3f4f6] text-[11px] font-medium uppercase tracking-wide text-[#9ca3af]">
              <tr>
                <th className="px-3 py-2.5 font-medium">Video</th>
                <th className="px-3 py-2.5 font-medium">Platform</th>
                <th className="px-3 py-2.5 font-medium">Posted at</th>
                <th className="px-3 py-2.5 font-medium">Duration</th>
                <th className="px-3 py-2.5 font-medium">Views</th>
                <th className="px-3 py-2.5 font-medium" />
                <th className="px-3 py-2.5 font-medium">Likes</th>
                <th className="px-3 py-2.5 font-medium">Comments</th>
                <th className="px-3 py-2.5 font-medium">Shares</th>
                <th className="px-3 py-2.5 font-medium">Saves</th>
                <th className="px-3 py-2.5 font-medium">Eng.</th>
                <th className="px-3 py-2.5 font-medium">Status</th>
                <th className="px-3 py-2.5 font-medium">Last refresh</th>
                <th className="px-3 py-2.5 font-medium" />
              </tr>
            </thead>
            <tbody>
              {filtered.map((video) => {
                const eng = engagementRate(video);
                const growth = growthMultiplier(video.views, video.viewsPrev);
                return (
                  <tr key={video.id} className="border-b border-[#f3f4f6] last:border-0">
                    <td className="px-3 py-2.5">
                      <a
                        href={video.url}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-2.5"
                      >
                        <span className="relative h-12 w-9 shrink-0 overflow-hidden rounded-md bg-[#111827]">
                          {video.thumbnailUrl ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img
                              src={video.thumbnailUrl}
                              alt=""
                              className="h-full w-full object-cover"
                            />
                          ) : null}
                        </span>
                        <span className="min-w-0">
                          <span className="line-clamp-1 text-[13px] font-medium text-[#111827]">
                            {video.title || video.url}
                          </span>
                          <span className="block text-[12px] text-[#9ca3af]">
                            {video.author || "—"}
                          </span>
                        </span>
                      </a>
                    </td>
                    <td className="px-3 py-2.5 text-[13px] text-[#374151]">
                      {platformLabel(video.platform)}
                    </td>
                    <td className="whitespace-nowrap px-3 py-2.5 text-[12px] text-[#6b7280]">
                      {formatPostedAt(video.postedAt || video.createdAt)}
                    </td>
                    <td className="px-3 py-2.5 text-[13px] text-[#374151]">
                      {formatDuration(video.durationSeconds)}
                    </td>
                    <td className="px-3 py-2.5 text-[13px] font-medium text-[#111827]">
                      {formatCompact(video.views)}
                    </td>
                    <td className="px-3 py-2.5">
                      <GrowthPill value={growth} />
                    </td>
                    <td className="px-3 py-2.5 text-[13px]">{formatCompact(video.likes)}</td>
                    <td className="px-3 py-2.5 text-[13px]">{formatCompact(video.comments)}</td>
                    <td className="px-3 py-2.5 text-[13px]">{formatCompact(video.shares)}</td>
                    <td className="px-3 py-2.5 text-[13px]">{formatCompact(video.saves)}</td>
                    <td className="px-3 py-2.5 text-[13px]">{eng.toFixed(1)}%</td>
                    <td className="px-3 py-2.5">
                      <StatusOk />
                    </td>
                    <td className="whitespace-nowrap px-3 py-2.5 text-[12px] text-[#6b7280]">
                      {timeAgo(video.lastRefreshedAt || video.updatedAt)}
                    </td>
                    <td className="relative px-3 py-2.5">
                      <button
                        type="button"
                        onClick={() => setMenuId((id) => (id === video.id ? null : video.id))}
                        className="px-1 text-[#9ca3af]"
                        aria-label="More"
                      >
                        ⋯
                      </button>
                      {menuId === video.id ? (
                        <div className="absolute right-3 z-10 mt-1 w-32 rounded-xl border border-[#e5e7eb] bg-white py-1 shadow-lg">
                          <button
                            type="button"
                            onClick={() => void remove(video)}
                            className="block w-full px-3 py-1.5 text-left text-[13px] text-red-600"
                          >
                            Remove
                          </button>
                        </div>
                      ) : null}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
